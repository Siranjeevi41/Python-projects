a=input().strip()
b=int(input())
print(a[::-1][:b])