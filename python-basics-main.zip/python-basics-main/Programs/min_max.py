x=list(map(int,input().split()))
print(min(x) + max(x))