fibonacci_series=[0,1,1,2,3,5,8,13,21,34,55]

#odd numbers
odd_numbers=list(filter(lambda x: x%2 !=0, fibonacci_series))
print(odd_numbers)

#even numbers
even_numbers=list(filter(lambda x: x%2 ==0, fibonacci_series))
print(even_numbers)