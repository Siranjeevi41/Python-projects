languages=["R","C","C++","Java","Python"]
languages_iterator=languages.__iter__()
try:
    print(languages_iterator.__next__())
    print(languages_iterator.__next__())
    print(languages_iterator.__next__())
    print(languages_iterator.__next__())
    print(languages_iterator.__next__())
    print(languages_iterator.__next__())    #Throws an StopIterationError
except:
    print("StopIterationError")