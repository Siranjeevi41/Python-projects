# Create a Laptop class with properties like 
# - brand
# - model
# - price
# - company 
# - company DUNS (Data Universal Numbering System: a 9-digit unique identifier for businesses) number


# Now:
# 1. Implement a method called applyDiscount that calculates the discounted price based on a given discount percentage. 

# 2. Derive two classes:
# - BudgetLaptop
# - PremiumLaptop from the Laptop class. 

# Add specific properties and methods to each derived class, such as 
# - maximumRAM for BudgetLaptop and 
# - graphicsCard for PremiumLaptop
# - harDiskCapacity for both BudgetLaptop, PremiumLaptop

# 3. Override the applyDiscount method in each subclass to adjust the discount calculation based on the laptop type. 

# Create instances of both classes and test the applyDiscount method.

class Laptop:
    def __init__(self,brand,model,price,discount,company,company_DUNS):
        self.brand=brand
        self.model=model
        self.price=price
        self.discount=discount
        self.company=company
        self.company_DUNS=company_DUNS

    def applyDiscount(self):
        return "Discounted price is " + str(self.price * self.discount/100)
    
class BudgetLaptop(Laptop):
    def __init__(self, brand, model, price, discount, company, company_DUNS,maximumRAM,harDiskCapacity):
        super().__init__(brand, model, price, discount, company, company_DUNS)

        self.maximumRAM=maximumRAM
        self.harDiskCapacity=harDiskCapacity

    def applyDiscount(self):
        return "Discounted price is " + str(self.price * self.discount/100)


class PremiumLaptop(Laptop):
    def __init__(self, brand, model, price, discount, company, company_DUNS,graphicsCard,harDiskCapacity):
        super().__init__(brand, model, price, discount, company, company_DUNS)

        self.graphicsCard=graphicsCard
        self.harDiskCapacity=harDiskCapacity

    def applyDiscount(self):
        return "Discounted price is " + str(self.price * self.discount/100)

    
budgetlaptop=BudgetLaptop("Dell","INSPIRON 5518",67500,10,"DELL",987345621,"Dedicated","512GB")
premiumlaptop=PremiumLaptop("Apple","MacBook Pro",150000,15,"APPLE","763412026","Integrated","512GB")
print(budgetlaptop.applyDiscount())
print(premiumlaptop.applyDiscount())