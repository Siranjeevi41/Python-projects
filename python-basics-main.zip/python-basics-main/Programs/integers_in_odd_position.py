x= list(map(int, input().split()))
for i in range(0, len(x), 2):
    print(x[i], end=' ')