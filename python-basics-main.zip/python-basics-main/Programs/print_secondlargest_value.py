a=int(input())
b=[]
for i in range(a):
    c=int(input())
    b.append(c)
b.sort()
print(b[-2])