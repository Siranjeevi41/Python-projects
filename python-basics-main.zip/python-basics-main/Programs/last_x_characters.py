x=input().strip()
y=int(input())
print(x[-y:])