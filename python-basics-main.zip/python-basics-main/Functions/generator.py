def count(n):
    i=0
    while i<=n:
        yield i
        i+=1

x=count(7)
for num in x:
    print(num)
