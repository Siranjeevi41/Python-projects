A,B=list(map(int, input().split()))
for X in range( B, A-1, -1):
    print(X, end=' ')


#while B>=A:
#    print(B, end=' ')
#    B -=1