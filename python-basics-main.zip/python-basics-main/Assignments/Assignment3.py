# Create an Employee class with properties as:
# - compantId
# - departmetId
# - firstName
# - lastName
# - emailId
# - age
# - salary

# Implement a method called "calculateBonus" that calculates a bonus based on the salary. 

# Now derive two classes:
# - Manager
# - Engineer
# from the Employee class. 

# The Manager class should have an additional property 
# - for the number of subordinates

# The Engineer class should have an additional property 
# - for the number of projects completed

# Override the "calculateBonus" method in each subclass to calculate the bonus based on specific criteria. 

# Now execute your classes by creating instances and calling the "calculateBonus" method.


class Employee:
    def __init__(self,compantId,departmetId,firstName,lastName,emailId,age,salary):
        self.compantId=compantId
        self.departmentId=departmetId
        self.firstName=firstName
        self.lastName=lastName
        self.emailId=emailId
        self.age=age
        self.salary=salary

    def calculateBonus(self):
        if self.salary <=50000:
            return "Bonus is " + str(self.salary * 2.5/100)
        elif self.salary >50000:
            return "Bonus is " + str(self.salary * 5/100)
        
class Manager(Employee):
    def __init__(self, compantId, departmetId, firstName, lastName, emailId, age, salary,no_of_subordinates):
        super().__init__(compantId, departmetId, firstName, lastName, emailId, age, salary)

        self.no_of_subordinates=no_of_subordinates
        
    def calculateBonus(self):
        if self.salary <=100000:
            return "Bonus is " + str(self.salary * 5/100)
        elif self.salary >100000:
            return "Bonus is " + str(self.salary * 10/100)

class Engineer(Employee):
    def __init__(self, compantId, departmetId, firstName, lastName, emailId, age, salary,no_of_projects):
        super().__init__(compantId, departmetId, firstName, lastName, emailId, age, salary)

        self.no_of_projects=no_of_projects

    def calculateBonus(self):
        if self.salary <=75000:
            return "Bonus is " + str(self.salary * 3/100)
        elif self.salary >75000:
            return "Bonus is " + str(self.salary * 7/100)
        
person=Engineer("230512","315","chenchu","ramu","chenchuramur@gmail.com","23",80000,"20")
print(person.calculateBonus())