list=[12,23,34,45,56,67,78,89,90]
iter_lst=iter(list)
while True:
    try:
        print(iter_lst.__next__())
    except:
        print("End of list, exiting")
        break