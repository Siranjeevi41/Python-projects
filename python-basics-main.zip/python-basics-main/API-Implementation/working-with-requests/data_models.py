from markupsafe import escape
from db_connection import mysql

class Task:
    def __init__(self, name, description):
        self.name = name
        self.description = description

    def save(self):
        cur = mysql.connection.cursor()
        cur.execute("INSERT INTO tasks(name, description) VALUES(%s, %s)", (escape(self.name), escape(self.description)))
        mysql.connection.commit()
        cur.close()

    def get_all_data():
        cursor = mysql.connection.cursor()
        cursor.execute('''SELECT name, description FROM todo.tasks''')
        record_set = cursor.fetchall()
        cursor.close()
        return str(record_set)

