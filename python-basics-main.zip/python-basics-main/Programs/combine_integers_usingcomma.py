a,b,c = list(map(int, input().split()))
print(a,b,c, sep=",")