#  Attached are the two files. 
# village-1.json
# village-2.json

# Create a new file with all details, where the person belongs to :
# - Both the villages
# - Only in village-1
# - Only in village-2

import json

file1 = []
get_data = open("village-1.json", "r")
read_data = get_data.read()
file1.append(json.loads(read_data))
get_data.close()

file2 = []
getdata = open("village-2.json", "r")
readdata = getdata.read()
file2.append(json.loads(readdata))
getdata.close()

both_village = []
for i in file1:
    for j in file2:
        if i["UUID"] == j["UUID"]:
            both_village.append(i)
else:
    print("No people are in both the villages")