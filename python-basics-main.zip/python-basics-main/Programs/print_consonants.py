x= input().strip()
y="aeiouAEIOU"
for i in x:
    if i not in y:
        print(i, end=' ')