# log levels = Message
debug = ("Harmless debug Message") 
info = ("Just an information") 
warning = ("Its a Warning") 
error = ("Did you try to divide by zero") 
critical = ("Internet is down")
