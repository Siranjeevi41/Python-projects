from flask import Flask, request, make_response
from flask_mysqldb import MySQL
from markupsafe import escape

app=Flask(__name__)

app.config["MYSQL_HOST"]="localhost"
app.config["MYSQL_USER"]="root"
app.config["MYSQL_PASSWORD"]=""
app.config["MYSQL_DB"]="flaskapp"

mysql=MySQL(app)


@app.route("/api/v1/users")
def read_tasks():
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM users")
    fetchdata=cur.fetchall()
    cur.close()
    
    return str(fetchdata)

@app.route("/api/v1/user", methods=["POST"])
def create_tasks():
    if request.method=="POST":
        id=7
        name="Pavi"
        email="parshith18@gmail.com"

        cur=mysql.connection.cursor()
        cur.execute("INSERT INTO users(id,name,email) VALUES(%s, %s, %s)", (escape(id), escape(name), escape(email)))
        mysql.connection.commit()
        cur.close()

        return make_response({"details": {"errors":"none", "message":"successfull created the task"}}, 200)


if __name__ == "__main__":
    app.run(debug=True)