x,y=list(map(int, input().split()))
for z in range( x,y+1):
    print(z, end=' ')