# People belongs to both the villages
for i in a:
    if i["Full name"] in a == i["Full name"] in b:
        print(i["Full name"])
else:
    print("No people are in both the villages")


# People belongs to village-1
x=[]
for i in a:
    x.append(i)


# People belongs to village-2
y=[]
for i in b:
    y.append(i)
print(y)
