# Assignment:

# Case:
# Consider a factory that manufactures cars with different models:
# General Availability(GA)
# Special edition(SPX)
# Limited Edition(LE)

# Create a car model which is common for all the above models with below attributes & behaviours:
# {
#     "model": {
#       "id": "8787878d8d7d878d78efee", 
#       "displayName": "Tata Nano - LE"},
#     "acceptOrders": "true",
#     "engine": {
#       "id": "MTGBD37489IDUDU", 
#       "dateOfMake": "2022-03-28",
#       "fuelType": "diesel"},
#       "price": "700000"
#   }


# Default behaviour:
# Should initialize the above data for a model

# Specific behaviour:
# LE model should have cost 3X times than SPX model
# SPX model should have cost 2X times than GA model






class carModel:
    def __init__(self, model_id, display_name, accept_orders, engine_id, engine_date_of_make, engine_fuel_type, price):
        self.model = {
            "id": model_id,
            "displayName": display_name
        }
        self.acceptOrders = accept_orders
        self.engine = {
            "id": engine_id,
            "dateOfMake": engine_date_of_make,
            "fuelType": engine_fuel_type
        }
        self.price = price

    def total_cost(self):
        return self.price

class GA_Model(carModel):
    def __init__(self, model_id, display_name, accept_orders, engine_id, engine_date_of_make, engine_fuel_type, price):
        super().__init__(model_id, display_name, accept_orders, engine_id, engine_date_of_make, engine_fuel_type, price)

class SPX_Model(carModel):
    def __init__(self, model_id, display_name, accept_orders, engine_id, engine_date_of_make, engine_fuel_type, price):
        super().__init__(model_id, display_name, accept_orders, engine_id, engine_date_of_make, engine_fuel_type, price * 2)

class LE_Model(carModel):
    def __init__(self, model_id, display_name, accept_orders, engine_id, engine_date_of_make, engine_fuel_type, price):
        super().__init__(model_id, display_name, accept_orders, engine_id, engine_date_of_make, engine_fuel_type, price * 6)


ga_model = GA_Model("8787878d8d7d878d78efee", "Tata Nano - GA", True, "MTGBD37489IDUDU", "2022-03-28", "diesel", 700000)
spx_model = SPX_Model("8787878d8d7d878d78efee", "Tata Nano - SPX", True, "MTGBD37489IDUDU", "2022-03-28", "diesel", 700000)
le_model = LE_Model("8787878d8d7d878d78efee", "Tata Nano - LE", True, "MTGBD37489IDUDU", "2022-03-28", "diesel", 700000)

print(ga_model.total_cost())   
print(spx_model.total_cost())  
print(le_model.total_cost())   


# Output:
# 700000
# 1400000
# 4200000


