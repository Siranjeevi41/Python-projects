wordslist=list(map(str, input().split()))
for word in wordslist:
    if len(word)==5:
        print(word, end=' ')