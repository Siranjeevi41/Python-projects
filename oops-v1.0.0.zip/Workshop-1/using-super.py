class Base(object): 
  
    # Constructor 
    def __init__(self, x): 
        self.x = x  

    def printXY(self): 
       # Note that Base.x won't work here 
       # because super() is used in constructor 
       print(self.x) 
    
class Derived(Base): 
  
    # Constructor 
    def __init__(self, x, y): 
          
        ''' In Python 3.x, "super().__init__(name)" 
            also works''' 
        super(Derived, self).__init__(x) 
        self.printXY(self) # line #23 - from the current class
        super().printXY()
        self.y = y 
  
    def printXY(self): 
  
       # Note that Base.x won't work here 
       # because super() is used in constructor 
       print(self.x, self.y) 
  
  
# Driver Code 
d = Derived(10, 20) 
d.printXY() 