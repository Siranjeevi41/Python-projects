def evening_greeting(func):
    def function_wrapper(x):
        print("Good Evening "+ func.__name__)
        func(x)
    return function_wrapper

def morning_greeting(func):
    def function_wrapper(x):
        print("Good Morning "+ func.__name__)
        func(x)
    return function_wrapper

@evening_greeting
def ram(x):
    print(x)

ram("Hi..")