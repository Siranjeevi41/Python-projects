def func(name=None):
    if name is None:
        print("Hello Anonymous!")
    else:
        print("Hello " + name + "!")

func()
func("ramu")