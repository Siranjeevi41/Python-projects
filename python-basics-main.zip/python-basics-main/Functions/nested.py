def func1():
    a=15
    def func2():
        print(a)
    func2()
func1()