import requests

def call_api(url, data):
    response = requests.post(url, json=data)
    
    if response.status_code == 200:
        # Successful API call
        print("API call successful!")
        print("Response:", str(response.text))
    else:
        # Error handling
        print("API call failed!")
        print("Status code:", response.status_code)
        print("Error message:", response.text)

# Example usage
api_url = "http://127.0.0.1:5000/api/v1/user"  # Replace with the actual API URL
payload = {"key1": "value1", "key2": "value2"}  # Replace with your payload data

call_api(api_url, payload)