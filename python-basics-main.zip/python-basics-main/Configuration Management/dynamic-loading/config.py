DATABASE_CONFIG = {
    "host" : "localhost",
    "dbname" : "company",
    "user" : "user",
    "password" : "password",
    "port" : 3306
}