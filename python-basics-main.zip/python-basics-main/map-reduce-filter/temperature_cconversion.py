def fahrenheit(T):
    return ((float(9)/5)*T + 32)

def celcius(T):
    return ((float(5)/9)* (T - 32))

temp = (34.5, 37.9, 36.4, 33.7, 35.5)
# F = map(fahrenheit, temp)
# C = map(celcius, F)

temp_in_fahrenheit=list(map(fahrenheit, temp))
temp_in_celcius=list(map(celcius, temp_in_fahrenheit,))

print(temp_in_fahrenheit)
print(temp_in_celcius)
