X, N=list(map(int,input().split()))
for i in range( X, N+1, X):
    print(i, end=' ')