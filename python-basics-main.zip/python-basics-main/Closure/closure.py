def get_fn():
    a=10
    b=20
    def get():
        print(a)
        print(b)
        return (a, b)
    return get

gfn=get_fn()

print(gfn.__code__.co_freevars)             # ('a','b')
print(gfn.__closure__[0])                   # <cell at 0x000001FD5FBFBFD0: int object at 0x000001FD5FA90210>
print(gfn.__closure__[0].cell_contents)     # 10
print(gfn.__closure__[1].cell_contents)     # 20

