import functools

print(functools.reduce(lambda x,y: x+y, [12,23,34,45,56,67,78,89.90]))