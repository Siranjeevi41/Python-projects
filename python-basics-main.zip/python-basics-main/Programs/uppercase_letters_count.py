a=input()
b=[] 
for i in a:
    if i.isupper():
        b.append(i)
print(len(b))