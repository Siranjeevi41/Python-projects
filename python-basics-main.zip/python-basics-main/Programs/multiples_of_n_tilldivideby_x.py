a = int(input())
b = int(input())

i = 1
while 1:
    val = i * a
    if val % b != 0:
        print(val, end=' ')
        i += 1
    else:
        break
