class person:
    def __init__(self, fname,lname,age):
        self.fname=fname
        self.lname=lname
        self.age=age

    def printName(self):
        print(self.fname , self.lname , str(self.age))

class student(person):
    def __init__(self, fname, lname, age):
        super().__init__(fname, lname, age)
    
p1=student("Chenchu", "Ramu", 22)
p1.printName()