x=list(map(int, input().split()))
if( len(set(x)) == (len(x))):
    print( "YES" )
else:
    print( "NO" )