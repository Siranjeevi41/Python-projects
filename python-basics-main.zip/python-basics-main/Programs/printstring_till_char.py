a=input()
ch=input()
for i in range(0,len(a)):
    if a[i]==ch:
        break
    else:
        print(a[i], end='')