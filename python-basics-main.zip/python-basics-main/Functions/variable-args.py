def sum_avg(*num):
    x=0
    for i in num:
        x+=i
    return i/len(num)

a=sum_avg(10,20,30,40,50)
print(a)


def cars(**kwargs):
    for key, value in kwargs.items():
        print(key + ":" + value)

cars(car1="Volvo", car2="BMW", car3="Honda", car4="Toyota")
