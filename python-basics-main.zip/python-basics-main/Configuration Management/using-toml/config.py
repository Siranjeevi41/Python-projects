import toml

class Configuration:
    def __init__(self):
        data=toml.load("config.toml")
        print(data)
        print(data.get("dbConfig").get("db_host"))
        print(data.get("dbConfig").get("db_port"))

        print(data.get("fileConfig").get("allowedFileSize"))
        print(data.get("fileConfig").get("maxFilesCount"))


Configuration()
