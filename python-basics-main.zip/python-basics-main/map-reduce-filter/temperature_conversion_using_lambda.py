C=[34.5, 37.9, 36.4, 33.7, 35.5]

#converting celcius to fahrenheit
F=list(map(lambda x: (float(9)/5)*x + 32, C))
print(F)

#onverting fahrenheit to celcius
C=list(map(lambda x: (float(5)/9)* (x- 32), F))
print(C)
