class student:
    def __init__(self, name, marks=[]):
        self.name=name
        self.marks=marks

    def average(self):
        return "The average marks of " + self.name +" is " + str( sum(self.marks) / len(self.marks) )
    

std=student("Ramu",[10,20,30,40,50])
print(std.average())
