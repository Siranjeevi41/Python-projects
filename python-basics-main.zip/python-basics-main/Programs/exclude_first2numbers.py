x=list(map(int,input().split()))
for y in x[2:]:
    print(y, end=' ')