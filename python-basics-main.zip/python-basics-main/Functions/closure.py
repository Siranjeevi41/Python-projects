def func1(x):
    def func2(y):
        return x+y
    return func2
    
a=func1(5)
b=a(3)
print(b)