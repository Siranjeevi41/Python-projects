def outer_func():
    a=15
    def inner_func():
        a=30
        print("Inner_function :",a)
    inner_func()
    print("Outer_function :",a)

outer_func()