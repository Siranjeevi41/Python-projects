from flask import Flask, jsonify, request
from controllers import create_task, read_task
import logging
from logging.handlers import RotatingFileHandler


app = Flask(__name__)

app.route('/api/v1/task', methods=['POST'])(create_task)
app.route('/api/v1/tasks')(read_task)

@app.route('/api/v1')
def index():
    return {"version": "1.0.0"}

@app.route('/api/v1/echo', methods=['POST'])
def echo():
    return jsonify(request.json)


if __name__ == "__main__":
    
    logHandler = RotatingFileHandler('info.log', maxBytes=1000, backupCount=1)
    
    
    logHandler.setLevel(logging.INFO)

    
    app.logger.setLevel(logging.INFO)

    app.logger.addHandler(logHandler)    
    
    app.run(debug=True)