X=list(map(int, input().split()))
Y=int(input())
print("YES" if Y in X else "NO")