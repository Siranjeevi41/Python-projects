a=list(map(int, input().split()))
b=len(dict.fromkeys(a))
print(b)