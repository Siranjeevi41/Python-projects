import sys
import pymysql

sys.path.append("/opt/settings")
import config

def connect_db(dbname):
    if dbname != config.DATABASE_CONFIG["dbname"]:
        raise ValueError("couldn't find DB with given name")
    connect=pymysql.connect(host=config.DATABASE_CONFIG["host"],
                            user=config.DATABASE_CONFIG["user"],
                            password=config.DATABASE_CONFIG["password"],
                            port=config.DATABASE_CONFIG["port"])
    return connect

connect_db("company")