class student:
    def __init__(self,name,age):
        self.name=name
        self.age=age
    
    def vote(self):
        if self.age>=18:
            return "The age of "+ self.name +" is "+ str(self.age) + " and he is elligible to vote"
        else:
            return self.name + "'s age is less than 18"

    @staticmethod 
    def ageGroup(name,age):
        if age<=20:
            return  name +" belongs to the age group of 0 to 20"
        elif age>=21 and age<=50:
            return  name +" belongs to the age group of 21 to 50 "
        else:
            return  name +" belongs to the age group of 50 to 100"
            
std=student("Chenchu", 22)
print(std.vote())

print(student.ageGroup("ramu",70))