from merry import Merry

merry=Merry()

@merry._try
def write_to_file(filename, data):
    with open(filename, "w") as f:
        f.write(data)

@merry._except(IOError)
def ioerror():
    print("Error: can't write to file")

@merry._except(Exception)
def exception(e):
    print("Unexpected error: " + str(e))

write_to_file("../test_datax.txt", "data")