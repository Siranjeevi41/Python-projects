x=list(map(int,input().split()))
#print(type(x))
print(sum(x))