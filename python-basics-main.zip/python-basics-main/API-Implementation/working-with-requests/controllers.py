from flask import request, jsonify, make_response
from markupsafe import escape
from data_models import Task

def create_task():
    if  request.method == 'POST':
        contentJSON = request.get_json()
        name = escape(contentJSON['name'])
        description = escape(contentJSON['description'])

        if not name or not description:
            return jsonify({"details": {"errors":"invalid_data", "message":"invalid task data"}}), 400
        
        new_task=Task(name=name, description=description)
        new_task.save()

        return jsonify({"details": {"errors":"none", "message":"successfully cretaed the task"}}), 200
    
def read_task():
    tasks=Task.get_all_data()
    return jsonify(tasks), 200