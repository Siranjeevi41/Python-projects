mul = lambda a,b : a*b
x=mul(7,5)
print(x) 