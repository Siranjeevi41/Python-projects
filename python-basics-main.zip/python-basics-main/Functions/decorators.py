def lowercase(func):
    def modify():
        x=func()
        return x.lower()
    return modify

@lowercase
def words():
    return "HELLO WORLD !"

result= words()
print(result)