x=list(map(int,input().split()))
for y in x:
    if y % 2 !=0:
        print(y, end=' ')