x,y,z= list(map(int, input().split()))
if x<y<z:
    print("Ascending Order")
elif x>y>z:
    print("Descending Order")
else:
    print("Random Order")