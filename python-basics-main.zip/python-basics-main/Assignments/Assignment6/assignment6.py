import json

def extract_seconds(time_str):
    time1_seconds = float(time_str[:-1])
    return time1_seconds

def merge_files(file1_path,file2_path,file3_path,file4_path):

    with open(file1_path, "r") as file1:
        data1=json.load(file1)

    with open(file2_path, "r") as file2:
        data2=json.load(file2)

    with open(file3_path, "r") as file3:
        data3=json.load(file3)

    with open(file4_path, "r") as file4:
        data4=json.load(file4)

    merged_data = {
        "Passed": str(int(data1.get("Passed")) + int(data2.get("Passed")) + int(data3.get("Passed")) + int(data4.get("Passed"))),
        "Failed": str(int(data1.get("Failed")) + int(data2.get("Failed")) + int(data3.get("Failed")) + int(data4.get("Failed"))),
        "TimedOut": str(int(data1.get("TimedOut")) + int(data2.get("TimedOut")) + int(data3.get("TimedOut")) +int(data4.get("TimedOut"))),
        "FailedTests": data1["FaiedTests"] + data2["FaiedTests"] + data3["TimedOutTests"] + data4["TimedOutTests"],
        "TimedOutTests": data1["TimedOutTests"] + data2["TimedOutTests"] + data3["TimedOutTests"] + data4["TimedOutTests"],
        "Skipped": str(int(data1.get("Skipped")) + int(data2.get("Skipped")) + int(data3.get("Skipped")) + int(data4.get("Skipped"))),
        "Total": str(int(data1.get("Total")) + int(data2.get("Total")) + int(data3.get("Total")) +int(data4.get("Total"))),
        "ExecutionTime": str(extract_seconds(data1.get("ExecutionTime")) + extract_seconds(data2.get("ExecutionTime")) + extract_seconds(data3.get("ExecutionTime")) + extract_seconds(data4.get("ExecutionTime"))) + "s"

    }
    
    # Another way
    # result ={}
    # result["Passed"] = str(int(data1["Passed"]) + int(data2["Passed"]) + int(data3["Passed"]) + int(data4["Passed"]))
    # result["FailedTests"] = data1["FaiedTests"] + data2["FaiedTests"] + data3["FaiedTests"] + data4["FaiedTests"]
    # return result
    
    return merged_data


file1_path="C:\\Users\\chenchu\\Documents\\PYTHON\\Assignments\\Assignment6\\api.json"
file2_path="C:\\Users\\chenchu\\Documents\\PYTHON\\Assignments\\Assignment6\\e2e.json"
file3_path="C:\\Users\\chenchu\\Documents\\PYTHON\\Assignments\\Assignment6\\page.json"
file4_path="C:\\Users\\chenchu\\Documents\\PYTHON\\Assignments\\Assignment6\\security.json"

merged_json=merge_files(file1_path, file2_path,file3_path,file4_path)
print(json.dumps(merged_json, indent=2))